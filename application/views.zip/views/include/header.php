	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<meta name="author" content="Ocean Infosystem">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="#" type="image/gif" sizes="16x16">
	
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap-datepicker.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/dataTables.bootstrap.min.css');?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/dashboardstyle.css'); ?>">
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="https://use.fontawesome.com/be653a2bbf.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Courgette|Lobster|Righteous|Ubuntu+Condensed" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/mystyle.css'); ?>">